## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## -----------------------------------------------------------------------------
library(outRanger)

# Create data set with truely multivariate outlier
set.seed(3)
t <- seq(0, pi, by = 0.01)
dat <- data.frame(x = cos(t), y = sin(t) + runif(length(t), -0.1, 0.1))
dat[c(100, 200), ] <- cbind(c(-0.5, 0.5), c(0.4, 0.4))

plot(y ~ x, data = dat)

# Let's run outRanger on that data
ch <- outRanger(dat)

# What outliers did we find?
outliers(ch)

# Bingo! How does the fixed data set looks like?
plot(y ~ x, data = Data(ch))

# The number of outliers per variable
plot(ch)

## -----------------------------------------------------------------------------
irisWithOutliers <- generateOutliers(iris)
out <- outRanger(irisWithOutliers, splitrule = "extratrees", num.trees = 50)

# The worst outliers
head(outliers(out))

# Summary of outliers
summary(out)

# Basic plot of the number of outliers per variable
plot(out)

# Basic plot of the scores of the outliers per variable
plot(out, what = "scores")

# Sum
summary(out)
head(Data(out))

## -----------------------------------------------------------------------------
library(dplyr)

irisWithOutliers %>% 
  outRanger(verbose = 0) %>%
  Data() %>% 
  head()
  

## -----------------------------------------------------------------------------
(out <- outRanger(iris, allow_predictions = TRUE))
iris1 <- iris[1:2, ]
iris1$Sepal.Length[1] <- -1
pred <- predict(out, newdata = iris1)
outliers(pred)
Data(pred)

## -----------------------------------------------------------------------------
out <- outRanger(irisWithOutliers, Sepal.Length ~ Species)

# Summary
summary(out)

## -----------------------------------------------------------------------------
out <- outRanger(irisWithOutliers, . - Sepal.Length ~ .)

# Summary
summary(out)

## -----------------------------------------------------------------------------
outliers(outRanger(irisWithOutliers, max_n_outliers = 3))

## -----------------------------------------------------------------------------
out <- outRanger(irisWithOutliers, replace = "NA")
head(Data(out))

