## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## -----------------------------------------------------------------------------
library(outRanger)

# Generate data with outliers in numeric columns
irisWithOutliers <- generateOutliers(iris, seed = 34)
head(irisWithOutliers)
 
# Find outliers by random forest regressions and replace them by predictive mean matching.
(out <- outRanger(irisWithOutliers))

# Plot the number of outliers per numeric variable
plot(out)

# Information on all outliers
outliers(out)

# Resulting data set with replaced outliers
head(Data(out))


## -----------------------------------------------------------------------------
head(Data(outRanger(irisWithOutliers, splitrule = "extratrees", num.trees = 50)))

## -----------------------------------------------------------------------------
library(dplyr)

iris %>% 
  generateOutliers() %>% 
  outRanger(verbose = 0) %>%
  Data() %>% 
  head()
  

## -----------------------------------------------------------------------------
out <- outRanger(irisWithOutliers, Sepal.Length ~ Species)


