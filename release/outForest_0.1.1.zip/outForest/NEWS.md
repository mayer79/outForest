# outForest 0.1.1

Maintainance update, fixing a suboptimal "doi" format in the description field.

# outForest 0.1.0

This is the initial CRAN release.
